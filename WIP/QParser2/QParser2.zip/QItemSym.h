/*
 * QItemSym.h -- Symbol item class.
 *
 * Expecting: "symbol" P1
 * Example:   "symbol Vsin"
 *
 * Analysis:
 *   P1 -- Optional string.
 */
#pragma once

#include "QItemBase.h"

class QItemSym : public QItemBase {
public:
  QItemSym(std::string typeStr, std::string argStr);
  QItemSym(const QItemSym &other);
  std::shared_ptr<QItemBase> clone() const override;

  void parseItem() override;
  std::string toString() const override;

  // std::string symName;
  ArgString p1Str;

protected:
  // Add schematic-specific member variables as needed
};
