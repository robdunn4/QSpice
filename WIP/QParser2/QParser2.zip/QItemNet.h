/*
 * QItemNet.h -- Net class.
 *
 * Expecting: "net" (P1) P2 P3 P4 P5
 * Example:   "net (-1700,-800) 1 13 0 "GND""
 *
 * Analysis:
 *   P1 -- Endpoint coordinate?
 *   P2 -- ?
 *   P3 -- ?
 *   P4 -- ?
 *   P5 -- String value?
 */                                                                            \
#pragma once

#include "QItemBase.h"

class QItemNet : public QItemBase {
public:
  QItemNet(std::string typeStr, std::string argStr);
  QItemNet(const QItemNet &other);
  std::shared_ptr<QItemBase> clone() const override;

  void parseItem() override;
  std::string toString() const override;

  ArgPoint p1;
  ArgInt p2;
  ArgInt p3;
  ArgInt p4;
  ArgString p5;

protected:
  // Add schematic-specific member variables as needed
};
