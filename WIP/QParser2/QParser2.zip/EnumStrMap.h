// template for enum/string bi-directional lookups
#pragma once
#include <concepts>
#include <initializer_list>
#include <stdexcept>
#include <string>
#include <unordered_map>
#include <utility>

template <typename T>
concept EnumType = std::is_enum_v<T>;

template <EnumType EnumID, typename EnumStr = std::string> class EnumMapper {
private:
  std::unordered_map<EnumStr, EnumID> EnumStrToID;
  std::unordered_map<EnumID, EnumStr> EnumIDToStr;

public:
  EnumMapper() = default;

  EnumMapper(std::initializer_list<std::pair<EnumID, EnumStr>> mappings) {
    addMappings(mappings);
  }

  void addMapping(EnumID enumID, const EnumStr &enumStr) {
    EnumStrToID[enumStr] = enumID;
    EnumIDToStr[enumID] = enumStr;
  }

  void addMappings(std::initializer_list<std::pair<EnumID, EnumStr>> mappings) {
    for (const auto &[enumID, enumStr] : mappings) {
      addMapping(enumID, enumStr);
    }
  }

  EnumID strToEnum(const EnumStr &enumStr) const {
    auto it = EnumStrToID.find(enumStr);
    if (it == EnumStrToID.end()) {
      throw std::invalid_argument("Unknown EnumStr: " + enumStr);
    }
    return it->second;
  }

  EnumStr enumToStr(EnumID enumID) const {
    auto it = EnumIDToStr.find(enumID);
    if (it == EnumIDToStr.end()) {
      throw std::invalid_argument("Unknown EnumID enum value: " +
                                  std::to_string(static_cast<int>(enumID)));
    }
    return it->second;
  }
};

// Usage examples:
// Declare with initialization:
// enum class Status { Active, Inactive, Pending };
// EnumMapper<Status> statusMapper({
//     {Status::Active, "active"},
//     {Status::Inactive, "inactive"},
//     {Status::Pending, "pending"}
// });
//
// Status s = statusMapper.strToEnum("active");
// std::string str = statusMapper.enumToStr(Status::Active);

// Or declare empty and add later:
// EnumMapper<Status> statusMapper;
// statusMapper.addMappings({
//     {Status::Active, "active"},
//     {Status::Inactive, "inactive"}
// });