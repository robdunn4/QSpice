#include "QItemCmp.h"
#include "StrUtils.h"
#include <iostream>
#include <sstream>

QItemCmp::QItemCmp(std::string typeStr, std::string argStr)
    : QItemBase(typeStr, argStr) {
  // parseItem();
}

// copy constructor
QItemCmp::QItemCmp(const QItemCmp &other)
    : QItemBase(other), p1(other.p1), p2(other.p2), p3(other.p3) {}

// clone method
std::shared_ptr<QItemBase> QItemCmp::clone() const {
  return std::make_shared<QItemCmp>(*this);
}
void QItemCmp::parseItem() {
  // we expect:  "component (-1700,-500) 0 0"
  StrUtils::StrList strList = StrUtils::parseSubItems(argStr);

  // we expect three subStrings
  if (strList.size() != 3) {
    std::ostringstream oss;
    oss << "Unexpected content in " << typeStr << " " << argStr;
    throw std::invalid_argument(oss.str());
  }

  p1 = ArgPoint(strList[0]);
  p2 = ArgInt(strList[1]);
  p3 = ArgInt(strList[2]);
}

std::string QItemCmp::toString() const {
  // TODO: build string....
  // return typeStr + " " + argStr;
  // std::string str = typeStr + " " + ArgPoint::toString(p1) + " " +
  //                  ArgInt::toString(p2) + " " + ArgInt::toString(p3);
  std::string str =
      typeStr + " " + p1.toString() + " " + p2.toString() + " " + p3.toString();
  return str;
}
