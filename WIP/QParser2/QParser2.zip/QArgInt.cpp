#include "QArgInt.h"
#include <stdexcept>

bool QArgInt::parse(const std::string& str) {
    if (str.empty()) {
        return false;
    }
    
    try {
        size_t pos = 0;
        value_ = std::stoi(str, &pos);
        
        // Ensure entire string was consumed
        if (pos != str.length()) {
            return false;
        }
        
        return true;
    } catch (const std::invalid_argument&) {
        return false;
    } catch (const std::out_of_range&) {
        return false;
    }
}

std::string QArgInt::toString() const {
    return std::to_string(value_);
}

std::unique_ptr<QArg> QArgInt::clone() const {
    return std::make_unique<QArgInt>(value_);
}