#include "QItemDBG.h"
#include "iostream"

// this is a dummy class to use during development -- it does no actual parsing
// and throws no execptions

QItemDBG::QItemDBG(std::string typeStr, std::string argStr)
    : QItemBase(typeStr, argStr) {}

QItemDBG::QItemDBG(const QItemDBG &other) : QItemBase(other) {}

std::shared_ptr<QItemBase> QItemDBG::clone() const {
  return std::make_shared<QItemDBG>(*this);
}

void QItemDBG::parseItem() {
  // show error message for debugging
  std::cout << "*** Unhandled record type in QItemDBG: " << toString()
            << std::endl;
}

std::string QItemDBG::toString() const {
  std::string str = typeStr;
  if (argStr.length()) str += " " + argStr;
  return str;
}
