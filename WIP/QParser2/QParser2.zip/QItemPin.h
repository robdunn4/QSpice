/*
 * QItemPin.h -- Rectangle item class.
 *
 * Expecting: "pin" (P1) (P2) P3 P4 P5 P6 P7 P8
 * Example:   "pin (0,200) (0,0) 1 0 0 0x0 -1 "+""
 *
 * Analysis:
 *   P1 -- Endpoint coordinate?
 *   P2 -- Endpoint coordinate?
 *   P3 -- ?
 *   P4 -- ?
 *   P5 -- ?
 *   P6 -- Hex mask
 *   P7 -- ?
 *   P8 -- String value?
 */

#pragma once
#include "QArgUtils.h"
#include "QItemBase.h"

class QItemPin : public QItemBase {
public:
  QItemPin(std::string typeStr, std::string argStr);
  QItemPin(const QItemPin &other);
  std::shared_ptr<QItemBase> clone() const override;

  void parseItem() override;
  std::string toString() const override;

  ArgPoint p1;
  ArgPoint p2;
  ArgInt p3;
  ArgInt p4;
  ArgInt p5;
  ArgHex p6;
  ArgInt p7;
  ArgString p8;

protected:
  // Add schematic-specific member variables as needed
};
