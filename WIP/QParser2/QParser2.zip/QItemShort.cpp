#include "QItemShort.h"
#include "StrUtils.h"

QItemShort::QItemShort(std::string typeStr, std::string argStr)
    : QItemBase(typeStr, argStr) {}

QItemShort::QItemShort(const QItemShort &other)
    : QItemBase(other), bShorted(other.bShorted) {}

std::shared_ptr<QItemBase> QItemShort::clone() const {
  return std::make_shared<QItemShort>(*this);
}

void QItemShort::parseItem() {
  StrUtils::StrList strList = StrUtils::parseSubItems(argStr);
  if (strList.size() != 1) {
    std::string str = "Unexpected content in " + typeStr + " " + argStr;
    throw std::invalid_argument(str);
  }

  bShorted = ArgBool(argStr);
}

std::string QItemShort::toString() const {
  return typeStr + " " + bShorted.toString();
}
