#include "QItemShort.h"
#include "StrUtils.h"
#include <iostream>
#include <sstream>

QItemShort::QItemShort(std::string typeStr, std::string argStr)
    : QItemBase(typeStr, argStr) {
  // parseItem();
}

QItemShort::QItemShort(const QItemShort &other)
    : QItemBase(other), bShorted(other.bShorted) {}

std::shared_ptr<QItemBase> QItemShort::clone() const {
  return std::make_shared<QItemShort>(*this);
}

void QItemShort::parseItem() {
  StrUtils::StrList strList = StrUtils::parseSubItems(argStr);
  // we expect zero or one parameters
  if (strList.size() != 1) {
    std::ostringstream oss;
    oss << "Unexpected content in " << typeStr << " " << argStr;

    throw std::invalid_argument(oss.str());
  }

  bShorted = ArgBool(argStr);
  // bShorted = argStr; does this work?
}

std::string QItemShort::toString() const {
  return typeStr + " " + bShorted.toString();
}
