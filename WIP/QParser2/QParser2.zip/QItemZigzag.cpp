#include "QItemZigzag.h"
#include "StrUtils.h"
#include <iostream>
#include <sstream>

QItemZigzag::QItemZigzag(std::string typeStr, std::string argStr)
    : QItemBase(typeStr, argStr) {
  // parseItem();
}

QItemZigzag::QItemZigzag(const QItemZigzag &other)
    : QItemBase(other), p1(other.p1), p2(other.p2), p3(other.p3), p4(other.p4),
      p5(other.p5), p6(other.p6), p7(other.p7), p8(other.p8) {}

std::shared_ptr<QItemBase> QItemZigzag::clone() const {
  return std::make_shared<QItemZigzag>(*this);
}

void QItemZigzag::parseItem() {
  StrUtils::StrList strList = StrUtils::parseSubItems(argStr);

  // we expect three subStrings
  if (strList.size() != 8) {
    std::ostringstream oss;
    oss << "Unexpected content in " << typeStr << " " << argStr;
    throw std::invalid_argument(oss.str());
  }

  p1 = ArgPoint(strList[0]);
  p2 = ArgPoint(strList[1]);
  p3 = ArgInt(strList[2]);
  p4 = ArgInt(strList[3]);
  p5 = ArgInt(strList[4]);
  p6 = ArgHex(strList[5]);
  p7 = ArgInt(strList[6]);
  p8 = ArgInt(strList[7]);
}

std::string QItemZigzag::toString() const {
  std::string str = typeStr + " " + p1.toString() + " " + p2.toString() + " " +
                    p3.toString() + " " + p4.toString() + " " + p5.toString() +
                    " " + p6.toString() + " " + p7.toString() + " " +
                    p8.toString();
  return str;
}
