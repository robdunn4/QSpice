#include "QItemSch.h"
#include <iostream>
#include <sstream>

QItemSch::QItemSch(std::string typeStr, std::string argStr)
    : QItemBase(typeStr, argStr) {
  // parseItem();
}

QItemSch::QItemSch(const QItemSch &other) : QItemBase(other) {}

std::shared_ptr<QItemBase> QItemSch::clone() const {
  return std::make_shared<QItemSch>(*this);
}

void QItemSch::parseItem() {
  // we expect no additional text after "schematic"???
  if (!argStr.empty()) {
    std::ostringstream oss;
    oss << "Unexpected content in " << typeStr << " " << argStr;

    throw std::invalid_argument(oss.str());
  }

  // nothing more to do?
}

std::string QItemSch::toString() const { return typeStr; }
