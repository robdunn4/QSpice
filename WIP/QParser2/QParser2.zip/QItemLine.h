/*
 * QItemLine.h -- Component item class.
 *
 * Expecting: "line" (P1) (P2) P3 P4 P5 P6 P7
 * Example:   "line (0,-130) (0,-200) 0 0 0x1000000 -1 -1"
 *
 * Analysis:
 *   P1 -- Endpoint coordinate?
 *   P2 -- Endpoint coordinate?
 *   P3 -- ?
 *   P4 -- ?
 *   P5 -- Hex mask?
 *   P6 -- ?
 *   P7 -- ?
 */

#pragma once
#include "QItemBase.h"

class QItemLine : public QItemBase {
public:
  QItemLine(std::string typeStr, std::string argStr);
  QItemLine(const QItemLine &other);
  std::shared_ptr<QItemBase> clone() const override;

  void parseItem() override;
  std::string toString() const override;

  ArgPoint p1;
  ArgPoint p2;
  ArgInt p3;
  ArgInt p4;
  ArgHex p5;
  ArgInt p6;
  ArgInt p7;

protected:
  // Add schematic-specific member variables as needed
};
