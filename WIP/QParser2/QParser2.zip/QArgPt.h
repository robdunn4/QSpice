// #ifndef QARGPT_H
// #define QARGPT_H
//
// #include "QArg.h"
//
///**
// * @brief Point argument type
// *
// * Parses and stores 2D integer coordinates in format "(x,y)"
// * with no embedded spaces.
// */
// class QArgPt : public QArg {
// private:
//  int x_;
//  int y_;
//
// public:
//  QArgPt() : x_(0), y_(0) {}
//  QArgPt(int x, int y) : x_(x), y_(y) {}
//
//  bool parse(const std::string &str) override;
//  std::string toString() const override;
//  std::unique_ptr<QArg> clone() const override;
//  // Type getType() const override { return Type::Point; }
//
//  /**
//   * @brief Get the x coordinate
//   * @return The x value
//   */
//  int getX() const { return x_; }
//
//  /**
//   * @brief Get the y coordinate
//   * @return The y value
//   */
//  int getY() const { return y_; }
//
//  /**
//   * @brief Set the coordinates
//   * @param x The x value
//   * @param y The y value
//   */
//  void setCoordinates(int x, int y) {
//    x_ = x;
//    y_ = y;
//  }
//};
//
// #endif // QARGPT_H