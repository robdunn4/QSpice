/*
 * QItemArc3P.h -- Arc3P item class.
 *
 * Expecting: "arc3p" (P1) (P2) (P3) P4 P5 P6 P7 P8
 * Example:   "arc3p (0,0) (60,0) (30,0) 0 0 0x1000000 -1 -1"
 *
 * Analysis:
 *   P1 -- Endpoint coordinate?
 *   P2 -- Endpoint coordinate?
 *   P3 -- Endpoint coordinate?
 *   P4 -- ?
 *   P5 -- ?
 *   P6 -- Hex mask
 *   P7 -- ?
 *   P8 -- ?
 */

#pragma once
#include "QItemBase.h"

class QItemArc3P : public QItemBase {
public:
  QItemArc3P(std::string typeStr, std::string argStr);
  QItemArc3P(const QItemArc3P &other);
  std::shared_ptr<QItemBase> clone() const override;

  void parseItem() override;
  std::string toString() const override;

  ArgPoint p1;
  ArgPoint p2;
  ArgPoint p3;
  ArgInt p4;
  ArgInt p5;
  ArgHex p6;
  ArgInt p7;
  ArgInt p8;

protected:
  // Add schematic-specific member variables as needed
};
