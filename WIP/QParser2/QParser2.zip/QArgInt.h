#ifndef QARGINT_H
#define QARGINT_H

#include "QArg.h"

/**
 * @brief Integer argument type
 *
 * Parses and stores integer values.
 */
class QArgInt : public QArg {
private:
  int value_;

public:
  QArgInt() : value_(0) {}
  explicit QArgInt(int value) : value_(value) {}

  bool parse(const std::string &str) override;
  std::string toString() const override;
  std::unique_ptr<QArg> clone() const override;
  // Type getType() const override { return Type::Integer; }

  /**
   * @brief Get the integer value
   * @return The stored integer value
   */
  int getValue() const { return value_; }

  /**
   * @brief Set the integer value
   * @param value The value to set
   */
  void setValue(int value) { value_ = value; }
};

#endif // QARGINT_H