#include "QItemNet.h"
#include "StrUtils.h"
#include <iostream>
#include <sstream>

QItemNet::QItemNet(std::string typeStr, std::string argStr)
    : QItemBase(typeStr, argStr) {
  // parseItem();
}

QItemNet::QItemNet(const QItemNet &other)
    : QItemBase(other), p1(other.p1), p2(other.p2), p3(other.p3), p4(other.p4),
      p5(other.p5) {}

std::shared_ptr<QItemBase> QItemNet::clone() const {
  return std::make_shared<QItemNet>(*this);
}

void QItemNet::parseItem() {
  // we expect:  "component (-1700,-500) 0 0"
  StrUtils::StrList strList = StrUtils::parseSubItems(argStr);

  // we expect three subStrings
  if (strList.size() != 5) {
    std::ostringstream oss;
    oss << "Unexpected content in " << typeStr << " " << argStr;
    throw std::invalid_argument(oss.str());
  }

  p1 = ArgPoint(strList[0]);
  p2 = ArgInt(strList[1]);
  p3 = ArgInt(strList[2]);
  p4 = ArgInt(strList[3]);
  p5 = ArgString(strList[4]);
}

std::string QItemNet::toString() const {
  std::string str = typeStr + " " + p1.toString() + " " + p2.toString() + " " +
                    p3.toString() + " " + p4.toString() + " " + p5.toString();
  return str;
}
