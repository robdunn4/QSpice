#include "QSchTree.h"
#include <cstdlib>
#include <fstream>
#include <iostream>
#include <vector>

// Helper function to extract filename without extension
std::string getFilenameWithoutExtension(const std::string &filename) {
  size_t lastDot = filename.find_last_of('.');
  if (lastDot == std::string::npos) return filename;
  return filename.substr(0, lastDot);
}

// Helper function to get file extension
std::string getFileExtension(const std::string &filename) {
  size_t lastDot = filename.find_last_of('.');
  if (lastDot == std::string::npos) return "";
  return filename.substr(lastDot);
}

// Binary compare two files and report differences
// TODO:  Rework to remove redundant calculations, etc.
//        Simplify to not try to show exact differences.
bool binaryCompareFiles(const std::string &file1, const std::string &file2) {
  std::ifstream f1(file1, std::ios::binary);
  std::ifstream f2(file2, std::ios::binary);

  if (!f1.is_open()) {
    std::cerr << "Cannot open file: " << file1 << std::endl;
    return false;
  }

  if (!f2.is_open()) {
    std::cerr << "Cannot open file: " << file2 << std::endl;
    return false;
  }

  // Read both files into memory
  std::vector<char> data1((std::istreambuf_iterator<char>(f1)),
                          std::istreambuf_iterator<char>());
  std::vector<char> data2((std::istreambuf_iterator<char>(f2)),
                          std::istreambuf_iterator<char>());

  f1.close();
  f2.close();

  bool identical = data1.size() == data2.size();
  std::vector<size_t> differences;
  int diffCnt = 0;
  const int maxDiff = 10;
  // int maxSize = std::max(data1.size(), data2.size());
  int minSize = std::min(data1.size(), data2.size());

  std::cout << "\n=== Binary Comparison ===" << std::endl;
  for (int i = 0; i < minSize && diffCnt < maxDiff; i++) {
    if (data1[i] != data2[i]) {
      differences.push_back(i);
      identical = false;
    }
  }

  if (identical && data1.size() == data2.size()) {
    std::cout << "Files are identical (" << data1.size() << " bytes)"
              << std::endl;
    return true;
  }

  if (data1.size() != data2.size()) {
    size_t sizeDiff = std::abs(static_cast<ptrdiff_t>(data1.size()) -
                               static_cast<ptrdiff_t>(data2.size()));
    std::cout << "File sizes differ by " << sizeDiff << " bytes." << std::endl;
  }

  if (!differences.size()) {
    std::cout << "No differences before end of shorter file." << std::endl;
    return false;
  }

  std::cout << "Files differ at " << differences.size()
            << " location(s):" << std::endl;

  // Show first n differences
  size_t maxShow = std::min(differences.size(), size_t(maxDiff));
  for (size_t i = 0; i < maxShow; ++i) {
    size_t pos = differences[i];
    std::cout << "  Byte " << pos << ": 0x" << std::hex
              << static_cast<int>(static_cast<unsigned char>(data1[pos]))
              << " vs 0x"
              << static_cast<int>(static_cast<unsigned char>(data2[pos]))
              << std::dec << std::endl;
  }

  if (differences.size() > maxDiff) {
    std::cout << "  ... and " << (differences.size() - maxDiff)
              << " more differences" << std::endl;
  }

  return false;
}

int main(int argc, char *argv[]) {
  // Check for command line argument
  if (argc < 2) {
    std::cerr << "Usage: " << argv[0] << " <filename>" << std::endl;
    std::cerr << "Example: " << argv[0] << " sample_tree.txt" << std::endl;
    return 1;
  }

  std::string inputFilename = argv[1];

  // Generate output filename with "_out" suffix before extension
  std::string baseFilename = getFilenameWithoutExtension(inputFilename);
  std::string extension = getFileExtension(inputFilename);
  std::string outputFilename = baseFilename + "_out" + extension;

  std::cout << "=== Parsing Input File ===" << std::endl;
  std::cout << "Input file: " << inputFilename << std::endl;

  try {
    // Open input file
    std::ifstream inputFile(inputFilename, std::ios::binary);
    if (!inputFile.is_open()) {
      throw std::runtime_error("Cannot open file: " + inputFilename);
    }

    // Parse from stream
    auto parsedTree = QSchTree::parseFromStream(inputFile);
    inputFile.close();

    std::cout << "\n=== Parsed Tree Structure ===" << std::endl;
    parsedTree->printWithPrefix();

    // std::cout << "\n=== Parsed Tree Structure -- Breadth First ==="
    //           << std::endl;
    // parsedTree->printBreadthFirst();

    // Write to output file
    std::cout << "\n=== Writing Output File ===" << std::endl;
    std::cout << "Output file: " << outputFilename << std::endl;

    std::ofstream outputFile(outputFilename, std::ios::binary);
    if (!outputFile.is_open()) {
      throw std::runtime_error("Cannot create file: " + outputFilename);
    }

    parsedTree->writeToStream(outputFile);
    outputFile.close();

    // Binary compare input and output files
    binaryCompareFiles(inputFilename, outputFilename);
  } catch (const std::exception &e) {
    std::cerr << "Error: " << e.what() << std::endl;
    return 1;
  }

  return 0;
}