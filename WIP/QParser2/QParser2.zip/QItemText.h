/*
 * QItemText.h -- Component item class.
 *
 * Expecting: "text" (P1) P2 P3 P4 P5 P6 P7 P8
 * Example:   "text (100,150) 1 7 0 0x1000000 -1 -1 "V1""
 *
 * Analysis:
 *   P1 -- Anchor coordinate?
 *   P2 -- Float?
 *   P3 -- ?
 *   P4 -- ?
 *   P5 -- Hex value?
 *   P6 -- ?
 *   P7 -- ?
 *   P8 -- String value?
 */
#pragma once

#include "QItemBase.h"

class QItemText : public QItemBase {
public:
  QItemText(std::string typeStr, std::string argStr);
  QItemText(const QItemText &other);
  std::shared_ptr<QItemBase> clone() const override;

  void parseItem() override;
  std::string toString() const override;

  ArgPoint p1;
  ArgFloat p2;
  ArgInt p3;
  ArgInt p4;
  ArgHex p5;
  ArgInt p6;
  ArgInt p7;
  ArgString p8;

protected:
  // Add schematic-specific member variables as needed
};
