#include "QArgFloat.h"
#include <stdexcept>

bool QArgFloat::parse(const std::string& str) {
    if (str.empty()) {
        return false;
    }
    
    try {
        size_t pos = 0;
        value_ = std::stof(str, &pos);
        
        // Ensure entire string was consumed
        if (pos != str.length()) {
            return false;
        }
        
        return true;
    } catch (const std::invalid_argument&) {
        return false;
    } catch (const std::out_of_range&) {
        return false;
    }
}

std::string QArgFloat::toString() const {
    return std::to_string(value_);
}

std::unique_ptr<QArg> QArgFloat::clone() const {
    return std::make_unique<QArgFloat>(value_);
}