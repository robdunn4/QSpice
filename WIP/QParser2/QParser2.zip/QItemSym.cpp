#include "QItemSym.h"
#include "StrUtils.h"
#include <iostream>
#include <sstream>

QItemSym::QItemSym(std::string typeStr, std::string argStr)
    : QItemBase(typeStr, argStr) {}

QItemSym::QItemSym(const QItemSym &other)
    : QItemBase(other), p1Str(other.p1Str) {}

std::shared_ptr<QItemBase> QItemSym::clone() const {
  return std::make_shared<QItemSym>(*this);
}

void QItemSym::parseItem() {
  StrUtils::StrList strList = StrUtils::parseSubItems(argStr);
  // we expect zero or one parameters
  if (strList.size() > 1) {
    std::ostringstream oss;
    oss << "Unexpected content in " << typeStr << " " << argStr;

    throw std::invalid_argument(oss.str());
  }

  // if (strList.size()) symName = strList[0];
  if (strList.size()) p1Str = ArgString(strList[0]);
}

std::string QItemSym::toString() const {
  // std::string str = typeStr;
  // if (symName.length()) str += " " + symName;
  std::string str = StrUtils::trim(typeStr + " " + p1Str.toString());
  return str;
}
