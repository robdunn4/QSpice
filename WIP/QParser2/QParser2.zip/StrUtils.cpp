#include "StrUtils.h"
#include <iostream>
#include <regex>
#include <sstream>

namespace StrUtils {

int strToInt(const std::string &str) {
  try {
    std::string trimmed = trim(str);
    if (trimmed.empty()) {
      throw std::invalid_argument("Empty string");
    }
    return std::stoi(trimmed);
  } catch (const std::exception &e) {
    throw std::runtime_error("Cannot convert '" + str +
                             "' to int: " + e.what());
  }
}

long strToLong(const std::string &str) {
  try {
    std::string trimmed = trim(str);
    if (trimmed.empty()) {
      throw std::invalid_argument("Empty string");
    }
    return std::stol(trimmed);
  } catch (const std::exception &e) {
    throw std::runtime_error("Cannot convert '" + str +
                             "' to long: " + e.what());
  }
}

float strToFloat(const std::string &str) {
  try {
    std::string trimmed = trim(str);
    if (trimmed.empty()) {
      throw std::invalid_argument("Empty string");
    }
    return std::stof(trimmed);
  } catch (const std::exception &e) {
    throw std::runtime_error("Cannot convert '" + str +
                             "' to float: " + e.what());
  }
}

double strToDouble(const std::string &str) {
  try {
    std::string trimmed = trim(str);
    if (trimmed.empty()) {
      throw std::invalid_argument("Empty string");
    }
    return std::stod(trimmed);
  } catch (const std::exception &e) {
    throw std::runtime_error("Cannot convert '" + str +
                             "' to double: " + e.what());
  }
}

std::string intToStr(int value) { return std::to_string(value); }

std::string longToStr(long value) { return std::to_string(value); }

std::string floatToStr(float value, int precision) {
  std::ostringstream oss;
  oss.precision(precision);
  oss << std::fixed << value;
  return oss.str();
}

std::string doubleToStr(double value, int precision) {
  std::ostringstream oss;
  oss.precision(precision);
  oss << std::fixed << value;
  return oss.str();
}

std::string trim(const std::string &str) { return trimLeft(trimRight(str)); }

std::string trimLeft(const std::string &str) {
  size_t start = str.find_first_not_of(" \t\n\r\f\v");
  return (start == std::string::npos) ? "" : str.substr(start);
}

std::string trimRight(const std::string &str) {
  size_t end = str.find_last_not_of(" \t\n\r\f\v");
  return (end == std::string::npos) ? "" : str.substr(0, end + 1);
}

// parse into elements
StrList parseSubItems(const std::string input) {
  StrList result;
  static const std::regex pattern(R"(".*"|\S+)");

  // TODO to fix below...
  auto begin = std::sregex_iterator(input.begin(), input.end(), pattern);
  auto end = std::sregex_iterator();

  for (auto &it = begin; it != end; ++it) {
    result.push_back(it->str());
  }

  return result;
}

} // namespace StrUtils