#include "StrUtils.h"
#include <iostream>
#include <sstream>

namespace StrUtils {

int strToInt(const std::string &str) {
  try {
    std::string trimmed = trim(str);
    if (trimmed.empty()) {
      throw std::invalid_argument("Empty string");
    }
    return std::stoi(trimmed);
  } catch (const std::exception &e) {
    throw std::runtime_error("Cannot convert '" + str +
                             "' to int: " + e.what());
  }
}

long strToLong(const std::string &str) {
  try {
    std::string trimmed = trim(str);
    if (trimmed.empty()) {
      throw std::invalid_argument("Empty string");
    }
    return std::stol(trimmed);
  } catch (const std::exception &e) {
    throw std::runtime_error("Cannot convert '" + str +
                             "' to long: " + e.what());
  }
}

float strToFloat(const std::string &str) {
  try {
    std::string trimmed = trim(str);
    if (trimmed.empty()) {
      throw std::invalid_argument("Empty string");
    }
    return std::stof(trimmed);
  } catch (const std::exception &e) {
    throw std::runtime_error("Cannot convert '" + str +
                             "' to float: " + e.what());
  }
}

double strToDouble(const std::string &str) {
  try {
    std::string trimmed = trim(str);
    if (trimmed.empty()) {
      throw std::invalid_argument("Empty string");
    }
    return std::stod(trimmed);
  } catch (const std::exception &e) {
    throw std::runtime_error("Cannot convert '" + str +
                             "' to double: " + e.what());
  }
}

std::string intToStr(int value) { return std::to_string(value); }

std::string longToStr(long value) { return std::to_string(value); }

std::string floatToStr(float value, int precision) {
  std::ostringstream oss;
  oss.precision(precision);
  oss << std::fixed << value;
  return oss.str();
}

std::string doubleToStr(double value, int precision) {
  std::ostringstream oss;
  oss.precision(precision);
  oss << std::fixed << value;
  return oss.str();
}

std::string trim(const std::string &str) { return trimLeft(trimRight(str)); }

std::string trimLeft(const std::string &str) {
  size_t start = str.find_first_not_of(" \t\n\r\f\v");
  return (start == std::string::npos) ? "" : str.substr(start);
}

std::string trimRight(const std::string &str) {
  size_t end = str.find_last_not_of(" \t\n\r\f\v");
  return (end == std::string::npos) ? "" : str.substr(0, end + 1);
}

// parseSubItems() -- parses a string into individual strings.
//
// Note:  This process is fragile.  It is possible for a GUI user to insert
// double-quotes into some fields which may break QSpice.  This code probably
// works no better...
//
// Original attempts used regex to parse quoted strings.  It failed when parsing
// rectangles that included image data due to massive string length.  Reworking
// to parse manually.
//
// TODO:  Revisit for speed...
//
StrList parseSubItems(const std::string &input) {
  StrList tokens;
  std::string current_token;
  bool in_quotes = false;

  for (size_t i = 0; i < input.length(); ++i) {
    char c = input[i];

    if (c == '"') {
      in_quotes = !in_quotes;
      // Optionally include quotes in the token:
      current_token += c;
    } else if (c == ' ' && !in_quotes) {
      // Space outside quotes - delimiter
      if (!current_token.empty()) {
        tokens.push_back(current_token);
        current_token.clear();
      }
    } else {
      // Regular character or space inside quotes
      current_token += c;
    }
  }

  // last token...
  if (!current_token.empty()) {
    tokens.push_back(current_token);
  }

  return tokens;
}

} // namespace StrUtils