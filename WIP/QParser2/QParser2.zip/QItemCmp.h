/*
 * QItemCmp.h -- Component item class.
 *
 * Expecting: "component" (P1) P2 P3
 * Example:   "component (-1700,-500) 0 0"
 *
 * Analysis:
 *   P1 -- Anchor coordinate?
 *   P2 -- Rotation/Alignment?
 *   P3 -- ???
 */
#pragma once

#include "QItemBase.h"

class QItemCmp : public QItemBase {
public:
  QItemCmp(std::string typeStr, std::string argStr);
  QItemCmp(const QItemCmp &other);
  std::shared_ptr<QItemBase> clone() const override;

  void parseItem() override;
  std::string toString() const override;

  ArgPoint p1;
  ArgInt p2;
  ArgInt p3;

protected:
  // Add schematic-specific member variables as needed
};
