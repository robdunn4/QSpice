#include "QItemTap.h"
#include "StrUtils.h"
#include <iostream>
#include <sstream>

QItemTap::QItemTap(std::string typeStr, std::string argStr)
    : QItemBase(typeStr, argStr) {}

QItemTap::QItemTap(const QItemTap &other)
    : QItemBase(other), p1(other.p1), p2(other.p2) {}

std::shared_ptr<QItemBase> QItemTap::clone() const {
  return std::make_shared<QItemTap>(*this);
}

void QItemTap::parseItem() {
  StrUtils::StrList strList = StrUtils::parseSubItems(argStr);

  if (strList.size() != 2) {
    std::ostringstream oss;
    oss << "Unexpected content in " << typeStr << " " << argStr;
    throw std::invalid_argument(oss.str());
  }

  p1 = ArgPoint(strList[0]);
  p2 = ArgPoint(strList[1]);
}

std::string QItemTap::toString() const {
  std::string str = typeStr + " " + p1.toString() + " " + p2.toString();
  return str;
}
