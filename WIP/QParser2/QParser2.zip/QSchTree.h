// QSchTree.h
#pragma once

#include "QItemBase.h"
#include <memory>
#include <string>
#include <vector>

class QSchTree {
public:
  static const unsigned char BEGIN_NODE = 0xAB;
  static const unsigned char END_NODE = 0xBB;

  // File identifier bytes
  static constexpr unsigned char FILE_ID[4] = {0xFF, 0xD8, 0xFF, 0xDB};

  std::string data;
  std::vector<std::shared_ptr<QSchTree>> children;
  int lineNbr;

  std::string typeStr;
  std::string dataStr;
  QPI enumID;
  std::shared_ptr<QItemBase> itemPtr;

  // Constructor that takes a string and parses it
  QSchTree(const std::string &value, int line = 0);

  // Copy constructor for cloning (creates deep copy)
  QSchTree(const QSchTree &other);

  // return node string (without beg/end markers)
  std::string toString() const;

  // Virtual destructor
  virtual ~QSchTree() = default;

  // Add a child node
  void addChild(std::shared_ptr<QSchTree> child);

  // Add a child with a string value
  void addChild(const std::string &value);

  // Parse data string into typeStr and dataStr
  void parseData();

  // Create a deep copy of this tree and all children
  std::shared_ptr<QSchTree> clone() const;

  // Depth-first traversal with indentation
  void printTree(int indent = 0) const;

  // Breadth-first traversal
  void printBreadthFirst() const;

  // Print with custom prefix using ASCII characters
  void printWithPrefix(const std::string &prefix = "",
                       bool isLast = true) const;

  // Write tree to stream
  void writeToStream(std::ostream &stream) const;

  // Parse tree from stream
  static std::shared_ptr<QSchTree> parseFromStream(std::istream &stream);

protected:
  // Recursive helper to write node to stream
  void writeNodeRecursive(std::ostream &stream, int indent = 0) const;

  // Recursive helper function to parse nodes from a stream
  static std::shared_ptr<QSchTree> parseNodeRecursive(std::istream &stream,
                                                      int &currentLine);
};