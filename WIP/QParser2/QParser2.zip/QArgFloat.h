#ifndef QARGFLOAT_H
#define QARGFLOAT_H

#include "QArg.h"

/**
 * @brief Floating-point argument type
 *
 * Parses and stores floating-point values.
 */
class QArgFloat : public QArg {
private:
  float value_;

public:
  QArgFloat() : value_(0.0f) {}
  explicit QArgFloat(float value) : value_(value) {}

  bool parse(const std::string &str) override;
  std::string toString() const override;
  std::unique_ptr<QArg> clone() const override;
  // Type getType() const  { return Type::Float; }

  /**
   * @brief Get the float value
   * @return The stored float value
   */
  float getValue() const { return value_; }

  /**
   * @brief Set the float value
   * @param value The value to set
   */
  void setValue(float value) { value_ = value; }
};

#endif // QARGFLOAT_H