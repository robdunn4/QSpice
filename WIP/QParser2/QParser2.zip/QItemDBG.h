/*
 * QItemDBG.h -- Dummy class for debugging.  Simply uses the line text.
 */
#pragma once
#include "QItemBase.h"

class QItemDBG : public QItemBase {
public:
  QItemDBG(std::string typeStr, std::string argStr);
  QItemDBG(const QItemDBG &other);
  std::shared_ptr<QItemBase> clone() const override;

  void parseItem() override;
  std::string toString() const override;

protected:
  // Add schematic-specific member variables as needed
};
