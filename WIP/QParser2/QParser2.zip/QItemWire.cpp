#include "QItemWire.h"
#include "StrUtils.h"
#include <iostream>
#include <sstream>

QItemWire::QItemWire(std::string typeStr, std::string argStr)
    : QItemBase(typeStr, argStr) {
  // parseItem();
}

QItemWire::QItemWire(const QItemWire &other)
    : QItemBase(other), p1(other.p1), p2(other.p2), p3(other.p3) {}

std::shared_ptr<QItemBase> QItemWire::clone() const {
  return std::make_shared<QItemWire>(*this);
}

void QItemWire::parseItem() {
  // we expect:  "component (-1700,-500) 0 0"
  StrUtils::StrList strList = StrUtils::parseSubItems(argStr);

  // we expect three subStrings
  if (strList.size() != 3) {
    std::ostringstream oss;
    oss << "Unexpected content in " << typeStr << " " << argStr;
    throw std::invalid_argument(oss.str());
  }

  p1 = ArgPoint(strList[0]);
  p2 = ArgPoint(strList[1]);
  p3 = ArgString(strList[2]);
}

std::string QItemWire::toString() const {
  std::string str =
      typeStr + " " + p1.toString() + " " + p2.toString() + " " + p3.toString();
  return str;
}
