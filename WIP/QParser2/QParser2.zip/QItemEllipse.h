/*
 * QItemEllipse.h -- Ellipse item class.
 *
 * Expecting: "ellipse" (P1) (P2) P3 P4 P5 P6 P7 P8 P9
 * Example:   "ellipse (-130,130) (130,-130) 0 0 0 0x1000000 0x1000000 -1 -1"
 *
 * Analysis:
 *   P1 -- Endpoint coordinate?
 *   P2 -- Endpoint coordinate?
 *   P3 -- ?
 *   P4 -- ?
 *   P5 -- ?
 *   P6 -- Hex mask
 *   P7 -- Hex mask
 *   P8 -- ?
 *   P9 -- ?
 */

#pragma once
#include "QItemBase.h"

class QItemEllipse : public QItemBase {
public:
  QItemEllipse(std::string typeStr, std::string argStr);
  QItemEllipse(const QItemEllipse &other);
  std::shared_ptr<QItemBase> clone() const override;

  void parseItem() override;
  std::string toString() const override;

  ArgPoint p1;
  ArgPoint p2;
  ArgInt p3;
  ArgInt p4;
  ArgInt p5;
  ArgHex p6;
  ArgHex p7;
  ArgInt p8;
  ArgInt p9;

protected:
  // Add schematic-specific member variables as needed
};
