// #include "QArgPt.h"
// #include <stdexcept>
//
// bool QArgPt::parse(const std::string& str) {
//     // Minimum valid string is "(x,y)" which is 5 characters
//     if (str.size() < 5) {
//         return false;
//     }
//
//     // Check for opening and closing parentheses
//     if (str.front() != '(' || str.back() != ')') {
//         return false;
//     }
//
//     // Check for spaces (not allowed)
//     if (str.find(' ') != std::string::npos) {
//         return false;
//     }
//
//     // Find the comma
//     size_t comma = str.find(',');
//     if (comma == std::string::npos || comma == 1 || comma == str.size() - 2)
//     {
//         // No comma, or comma right after '(' or right before ')'
//         return false;
//     }
//
//     // Check for multiple commas
//     if (str.find(',', comma + 1) != std::string::npos) {
//         return false;
//     }
//
//     try {
//         // Parse x value (between '(' and ',')
//         size_t pos = 0;
//         std::string xStr = str.substr(1, comma - 1);
//         x_ = std::stoi(xStr, &pos);
//
//         // Ensure entire x substring was consumed
//         if (pos != xStr.length()) {
//             return false;
//         }
//
//         // Parse y value (between ',' and ')')
//         pos = 0;
//         std::string yStr = str.substr(comma + 1, str.size() - comma - 2);
//         y_ = std::stoi(yStr, &pos);
//
//         // Ensure entire y substring was consumed
//         if (pos != yStr.length()) {
//             return false;
//         }
//
//         return true;
//     } catch (const std::invalid_argument&) {
//         return false;
//     } catch (const std::out_of_range&) {
//         return false;
//     }
// }
//
// std::string QArgPt::toString() const {
//     return "(" + std::to_string(x_) + "," + std::to_string(y_) + ")";
// }
//
// std::unique_ptr<QArg> QArgPt::clone() const {
//     return std::make_unique<QArgPt>(x_, y_);
// }