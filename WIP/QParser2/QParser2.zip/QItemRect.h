/*
 * QItemRect.h -- Rectangle item class.
 *
 * Expecting: "rect" (P1) (P2) P3 P4 P5 P6 P7 P8 P9 P10
 * Example:   "rect (-25,77) (25,73) 0 0 0 0x1000000 0x3000000 -1 0 -1"
 *
 * With graphic: "rect" (P1) (P2) P3 P4 P5 P6 P7 P8 P9 P10 P11
 * Example:      "rect (3018,68) (3082,132) 0 0 2 0xff0000 0x5000000 -1 0 -1
 *                89504e470d0a1a0a...0000014f0000"
 *
 * Analysis:
 *   P1 -- Endpoint coordinate?
 *   P2 -- Endpoint coordinate?
 *   P3 -- ?
 *   P4 -- ?
 *   P5 -- ?
 *   P6 -- Hex mask
 *   P7 -- Hex mask
 *   P8 -- ?
 *   P9 -- ?
 *   P10 -- ?
 *   P11 -- Appears to be used only for a graphic image, a string of hex values
 *          with no embedded spaces/newlines.  Not included if no graphic.
 */

#pragma once
#include "QItemBase.h"

class QItemRect : public QItemBase {
public:
  QItemRect(std::string typeStr, std::string argStr);
  QItemRect(const QItemRect &other);
  std::shared_ptr<QItemBase> clone() const override;

  void parseItem() override;
  std::string toString() const override;

  ArgPoint p1;
  ArgPoint p2;
  ArgInt p3;
  ArgInt p4;
  ArgInt p5;
  ArgHex p6;
  ArgHex p7;
  ArgInt p8;
  ArgInt p9;
  ArgInt p10;
  ArgString p11;

protected:
  // Add schematic-specific member variables as needed
};
