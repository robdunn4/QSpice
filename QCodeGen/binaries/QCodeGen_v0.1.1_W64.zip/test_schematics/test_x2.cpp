// Automatically generated C++ file on Sun Feb 11 16:57:21 2024
//
// To build with Digital Mars C++ Compiler: 
//
//    dmc -mn -WD test_x2.cpp kernel32.lib

union uData
{
   bool b;
   char c;
   unsigned char uc;
   short s;
   unsigned short us;
   int i;
   unsigned int ui;
   float f;
   double d;
   long long int i64;
   unsigned long long int ui64;
   char *str;
   unsigned char *bytes;
};

// int DllMain() must exist and return 1 for a process to load the .DLL
// See https://docs.microsoft.com/en-us/windows/win32/dlls/dllmain for more information.
int __stdcall DllMain(void *module, unsigned int reason, void *reserved) { return 1; }

// #undef pin names lest they collide with names in any header file(s) you might include.
#undef In_d
#undef In_b
#undef In_i
#undef In_i64
#undef Out_d
#undef Out_b
#undef Out_i
#undef Out_i64
#undef In_c
#undef In_uc
#undef In_s
#undef In_ui
#undef In_f
#undef In_ui64
#undef Out_c
#undef Out_uc
#undef In_us
#undef Out_s
#undef Out_us
#undef Out_ui
#undef Out_f
#undef Out_ui64
#undef _x_x_x_1
#undef In_bv

extern "C" __declspec(dllexport) void test_x2(void **opaque, double t, union uData *data)
{
   double                  In_d     = data[ 0].d   ; // input
   bool                    In_b     = data[ 1].b   ; // input
   int                     In_i     = data[ 2].i   ; // input
   long long int           In_i64   = data[ 3].i64 ; // input
   char                    In_c     = data[ 4].c   ; // input
   unsigned char           In_uc    = data[ 5].uc  ; // input
   short                   In_s     = data[ 6].s   ; // input
   unsigned int            In_ui    = data[ 7].ui  ; // input
   float                   In_f     = data[ 8].f   ; // input
   unsigned long long int  In_ui64  = data[ 9].ui64; // input
   unsigned short          In_us    = data[10].us  ; // input
   long long int           _x_x_x_1 = data[11].i64 ; // input
   bool                    In_bv    = data[12].b   ; // input
   const char *            Attr2    = data[13].str ; // input parameter
   const char *            Attr3    = data[14].str ; // input parameter
   const char *            Attr4    = data[15].str ; // input parameter
   const char *            Attr5    = data[16].str ; // input parameter
   bool                    Attr6    = data[17].b   ; // input parameter
   char                    Attr7    = data[18].c   ; // input parameter
   char                    Attr8    = data[19].c   ; // input parameter
   int                     Attr9    = data[20].i   ; // input parameter
   int                     Attr10   = data[21].i   ; // input parameter
   const char *            Attr11   = data[22].str ; // input parameter
   double                  Attr12   = data[23].d   ; // input parameter
   double                  Attr13   = data[24].d   ; // input parameter
   const char *            Attr14   = data[25].str ; // input parameter
   const char *            Attr15   = data[26].str ; // input parameter
   const char *            Attr16   = data[27].str ; // input parameter
   double                 &Out_d    = data[28].d   ; // output
   bool                   &Out_b    = data[29].b   ; // output
   int                    &Out_i    = data[30].i   ; // output
   long long int          &Out_i64  = data[31].i64 ; // output
   char                   &Out_c    = data[32].c   ; // output
   unsigned char          &Out_uc   = data[33].uc  ; // output
   short                  &Out_s    = data[34].s   ; // output
   unsigned short         &Out_us   = data[35].us  ; // output
   unsigned int           &Out_ui   = data[36].ui  ; // output
   float                  &Out_f    = data[37].f   ; // output
   unsigned long long int &Out_ui64 = data[38].ui64; // output

// Implement module evaluation code here:

}
