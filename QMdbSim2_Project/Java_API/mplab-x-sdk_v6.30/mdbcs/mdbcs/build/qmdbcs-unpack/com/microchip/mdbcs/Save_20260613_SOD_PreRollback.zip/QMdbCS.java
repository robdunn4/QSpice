package com.microchip.mdbcs;

import com.microchip.mplab.mdbcore.debugger.ToolEvent;
import com.microchip.mplab.util.observers.Observer;
import java.util.concurrent.CountDownLatch;
import java.util.concurrent.TimeUnit;

/**
 * QMdbCS -- thin façade over MDBCS Debugger for use by QSpice C-Block
 * components via JNI.  Aggregates related calls to minimize JNI boundary
 * crossings.
 *
 * C++ holds a QMdbCS instance and calls its methods directly.  Pin objects
 * returned by getPin() are cached as JNI global refs on the C++ side and
 * passed back in on each getPinState() call -- no per-call name lookup.
 */
public class QMdbCS {

    private final Debugger dbg;

    // ── HALT observer -- zero-poll step completion ─────────────────────────
    //
    // stepInstr() in Debugger.java calls mdb.StepInstr() but does NOT call
    // waitFor(HALTED) before returning, unlike stepOver() which does.  This is
    // a bug in MDBCS Debugger.java: the step is dispatched asynchronously but
    // the caller gets control back before the simulator's HALT event fires.
    // Reading pin state immediately after stepInstr() therefore sees stale
    // values, causing QSpice solver non-convergence in Release builds.
    //
    // Fix: attach our own Observer to the MDBCore Debugger.  Before each
    // stepInstr() call we arm a fresh CountDownLatch(1).  The observer fires
    // on the MDBCore background thread when HALT arrives and counts the latch
    // down.  stepInstr() then blocks on latch.await() -- which returns
    // immediately once the HALT fires, with no polling delay.
    //
    // Race-safety: haltLatch is assigned to a local variable and published to
    // the field BEFORE dbg.stepInstr() is dispatched.  The observer always
    // calls countDown() on the current haltLatch field value.  A stale HALT
    // from a previous step that fires between steps will call countDown() on
    // the already-zeroed previous latch (a no-op on CountDownLatch), not on
    // the newly armed one.  This prevents the /O2 scheduling scenario where a
    // late-arriving HALT prematurely releases the latch for the next step.
    private volatile CountDownLatch haltLatch = new CountDownLatch(0);

    private final Observer haltObserver = new Observer() {
        @Override
        public void Update(Object o) {
            if (o instanceof ToolEvent) {
                ToolEvent.EVENTS ev = ((ToolEvent) o).GetEvent();
                if (ev == ToolEvent.EVENTS.HALT) {
                    haltLatch.countDown(); // release stepInstr() waiter
                }
            }
        }
    };

    // ── Version ───────────────────────────────────────────────────────────

    public static String getVersion() { return "0.11.0"; }

    // ── Construction / lifecycle ──────────────────────────────────────────

    public QMdbCS(String device, String tool, boolean asDebugger)
            throws MException {
        dbg = new Debugger(device, tool, asDebugger);
        // Attach our HALT observer to the MDBCore Debugger so stepInstr()
        // can block on a latch instead of polling isHalted().
        dbg.attachObserver(haltObserver);
    }

    public void loadFile(String path)   throws MException { dbg.loadFile(path); }
    public void connect()               throws MException { dbg.connect(); }
    public void program()               throws MException { dbg.program(); }
    public void reset()                 throws MException { dbg.reset(); }
    public void disconnect()                             { dbg.disconnect(); }
    public void destroy()                                { dbg.destroy(); }
    public long stepInstr() throws MException {
        // Arm a fresh latch and publish it to haltLatch BEFORE dispatching
        // the step.  The observer always calls countDown() on whatever
        // haltLatch currently points to.  By updating the field first, any
        // stale HALT from the previous step that fires in the window between
        // steps will countDown() the already-zeroed prior latch (a no-op),
        // not this new one.  This closes the /O2 race where late-arriving
        // HALT events from a prior step prematurely release the next step's
        // latch before the instruction has actually completed.
        CountDownLatch latch = new CountDownLatch(1);
        haltLatch = latch;          // publish before dispatch -- see comment above
        long pc = dbg.stepInstr();  // dispatches StepInstr(); HALT fires async
        // Block until HALT fires (zero polling -- wakes instantly on event).
        // 5-second timeout matches Debugger.java's DEFAULT_TIME_OUT.
        try {
            if (!latch.await(5, TimeUnit.SECONDS)) {
                throw new MException("stepInstr: timeout waiting for HALT event");
            }
        } catch (InterruptedException e) {
            Thread.currentThread().interrupt();
            throw new MException("stepInstr: interrupted waiting for HALT event");
        }
        return pc;
    }
    public void setVDD(float vdd)       throws MException { dbg.setVDD(vdd); }
    public java.util.Properties getToolProperties()      { return dbg.getToolProperties(); }

    // ── Pin access ────────────────────────────────────────────────────────

    /**
     * Returns a Pin object for the named pin.  The C++ side promotes the
     * returned reference to a JNI global ref and caches it for the session.
     */
    public Pin getPin(String name) throws MException { return dbg.getPin(name); }

    // ── Aggregated pin state -- one JNI call per pin per step ─────────────
    //
    // Returns a packed long:
    //
    //   Bits 63..32  voltage as IEEE 754 float bits (Float.floatToRawIntBits)
    //   Bit  1       1 = digital output, 0 = input / hi-Z
    //   Bit  0       1 = analog, 0 = digital
    //
    // Voltage precision: the underlying Debugger returns a double, but only
    // 32 bits are available in the packed long, so it is cast to float before
    // packing.  This gives ~7 significant decimal digits (~0.0000002 V at
    // 3.3 V).  The precision loss is intentional and considered acceptable
    // for pin voltage monitoring at simulator step rates.
    //
    // ADState is queried once via isAnalog(); isDigitalOutput() is only
    // called when the pin is known to be digital, so getADState() is called
    // exactly once per pin per step.
    // The Pin object is a cached global ref passed in from C++ -- no lookup.

    public long getPinState(Pin pin) {
        boolean analog  = pin.isAnalog();
        boolean output  = !analog && pin.isDigitalOutput();
        float   voltage = (float) pin.getVoltage();   // double→float: ~7 sig. digits, acceptable
        return ((long) Float.floatToRawIntBits(voltage) << 32)
             | (output ? 2L : 0L)
             | (analog ? 1L : 0L);
    }

    // ── External stimulus ─────────────────────────────────────────────────

    public void pinExternalSetVoltage(Pin pin, double v) {
        pin.externalSetVoltage(v);
    }
}