/*==============================================================================
 * TruncTest.cpp -- QSpice C-Block code to investigate Trunc() behavior.
 *============================================================================*/
#include <cstdlib>

/*------------------------------------------------------------------------------
 * Versioning Information
 *----------------------------------------------------------------------------*/
#define PROGRAM_NAME    "TruncTest"
#define PROGRAM_VERSION "v0.1"
#define PROGRAM_INFO    PROGRAM_NAME " " PROGRAM_VERSION

// must follow above versioning information
#include "Cblock.h"

/*------------------------------------------------------------------------------
 * DbgLog
 *----------------------------------------------------------------------------*/
// declare DbgLog instance for logging; instance name must be dbgLog; change
// file name and max line limit if desired (-1 = max).
#include "DbgLog.h"
DbgLog dbgLog("@qdebug.log", 1000);

/*------------------------------------------------------------------------------
 * Per-instance Data
 *----------------------------------------------------------------------------*/
struct InstData {
  double tLastEval;   // sim time (t param) of last evaluation function call
  double tsLastTruncStep;   // timestep returned by last Trunc() call
  int    evalCtr;
  int    truncCtr;
};

/*------------------------------------------------------------------------------
 * UDATA() definition -- regenerate the template with QSpice and revise this
 * whenever ports/attributes change; make input/attribute parameters const&
 *----------------------------------------------------------------------------*/
#define UDATA(data)                                                            \
  const double &In            = data[0].d; /* input */                         \
  const int    &SomeAttribute = data[1].i; /* input parameter */               \
  double       &Out           = data[2].d; /* output */

/*------------------------------------------------------------------------------
 * Evaluation Function
 *----------------------------------------------------------------------------*/
extern "C" __declspec(dllexport) void trunctest(
    InstData **opaque, double t, uData data[]) {

  UDATA(data);

  InstData *inst = *opaque;

  if (!*opaque) {
    inst = *opaque = new InstData;

    if (!*opaque) {
      // terminate with prejudice
      msg("Memory allocation failure.  Terminating simulation.\n");
      exit(1);
    }

    // if important, output component parameters
    msg("Component loaded (SomeAttribute=%d).\n", SomeAttribute);
  }

  LOGT("eval() t=%e, In=%e", t, In);

  const int truncDivs = 4;   // number of times to divide timestep by 2
  inst->tLastEval     = t;
  inst->truncCtr      = inst->evalCtr;
  // don't start trunc divs until time > 0
  if (t > 0.0) inst->evalCtr = ++inst->evalCtr % truncDivs;

  Out = In;
}

/*------------------------------------------------------------------------------
 * MaxExtStepSize()
 *----------------------------------------------------------------------------*/
extern "C" __declspec(dllexport) double MaxExtStepSize(InstData &inst) {

  double retVal = 1e308;   // default == eternity

  // some testing/debugging stuff...
  // if you want the first evalfunc() call to be shorter than the default
  // (whatever QSpice decides), you have to do it here because Trunc() isn't
  // called until after the first evalfunc() call...
  retVal = 5e-6;
  LOG("MaxExtStepSize() returning %e", retVal);

  return retVal;
}

/*------------------------------------------------------------------------------
 * Trunc()
 *----------------------------------------------------------------------------*/
extern "C" __declspec(dllexport) void Trunc(
    InstData &inst, double t, uData data[], double *timestep) {

  UDATA(data);

  // calculate proposed timestep
  double step = t - inst.tLastEval;

  LOGT("Trunc() entry: t=%e, *timestep=%-12e, step=%e", t, *timestep, step,
      inst.tLastEval + step);

  if (inst.truncCtr) {
    inst.truncCtr--;
    step /= 2;
    // limit minimum steptime
    if (step < 1e-9) step = 1e-9;
  }
  *timestep = step;

  LOGT("Trunc() exit:  t=%e, *timestep=%-12e, step=%e, next eval()=%e", t,
      *timestep, step, inst.tLastEval + step);
}

/*------------------------------------------------------------------------------
 * Destroy()
 *----------------------------------------------------------------------------*/
extern "C" __declspec(dllexport) void Destroy(InstData &inst) {
  // free allocated memory
  delete &inst;
}
/*==============================================================================
 * End of TruncTest.cpp
 *============================================================================*/
